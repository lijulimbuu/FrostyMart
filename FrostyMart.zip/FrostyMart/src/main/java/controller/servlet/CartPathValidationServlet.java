package controller.servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.DatabaseController;
import model.CartModel;

import java.io.IOException;

@WebServlet("/CartPathValidationServlet")
public class CartPathValidationServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    HttpSession session = request.getSession(false);
	    if (session == null || session.getAttribute("userId") == null) {
	        // User is not logged in, redirect to login page
	        response.sendRedirect(request.getContextPath() + "/login.jsp");
	        return; // Stop further processing
	    }

	    // User is logged in, proceed with adding item to cart
	    int userId = (int) session.getAttribute("userId");
	    int productId = Integer.parseInt(request.getParameter("productId"));
	    int quantity = Integer.parseInt(request.getParameter("quantity"));
	    double price = Double.parseDouble(request.getParameter("price"));

	    CartModel cartObj = new CartModel(productId, userId, quantity, (int) price);

	    // Assuming AddToCart returns a boolean indicating success
	    boolean itemAdded = DatabaseController.AddToCart(cartObj);

	    if (itemAdded) {
	        // Send success message or redirect to cart page
	        response.sendRedirect(request.getContextPath() + "/pages/cart.jsp");
	    } else {
	        // Handle the case where adding to cart fails
	        // You can redirect to an error page or display an error message
	        response.sendRedirect(request.getContextPath() + "/error.jsp");
	    }
	}

}
